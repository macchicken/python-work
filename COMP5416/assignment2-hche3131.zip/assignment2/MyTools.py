def printLogToConsole(logstr):
	print "\n"+logstr